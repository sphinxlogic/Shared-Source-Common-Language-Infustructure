/*
 * tclWinThrd.h --
 *
 *      This header file defines things for thread support.
 *
 * Copyright (c) 1998 Sun Microsystems, Inc.
 *
 * See the file "license.terms" for information on usage and redistribution
 * of this file, and for a DISCLAIMER OF ALL WARRANTIES.
 *
 * SCCS: @(#) tclWinThrd.h 1.2 98/01/27 11:48:05
 */
 
#ifndef _TCLWINTHRD
#define _TCLWINTHRD

#ifdef TCL_THREADS

#endif /* TCL_THREADS */

#endif /* _TCLWINTHRD */
