#if __POWERPC__
#include "MW_TkStaticHeaderPPC"
#elif __CFM68K__
#include "MW_TkStaticHeaderCFM68K"
#else
#include "MW_TkStaticHeader68K"
#endif
